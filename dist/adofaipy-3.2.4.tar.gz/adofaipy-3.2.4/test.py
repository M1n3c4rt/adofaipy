from adofaipy import *
level = LevelDict('level.adofai')

level.writeToFile()